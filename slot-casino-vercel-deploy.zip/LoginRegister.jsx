import { useState } from "react";

export default function LoginRegister({ onLogin }) {
  const [username, setUsername] = useState("");
  const [isRegister, setIsRegister] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = () => {
    if (!username) {
      setError("Nama pengguna wajib diisi.");
      return;
    }

    const saved = localStorage.getItem(`user:${username}`);
    if (isRegister) {
      if (saved) {
        setError("Nama pengguna sudah terdaftar.");
        return;
      }
      const newUser = { username, credits: 100000 };
      localStorage.setItem(`user:${username}`, JSON.stringify(newUser));
      onLogin(newUser);
    } else {
      if (!saved) {
        setError("Akun tidak ditemukan.");
        return;
      }
      onLogin(JSON.parse(saved));
    }
  };

  return (
    <div style={{ padding: '2rem', textAlign: 'center' }}>
      <h2>{isRegister ? "Daftar" : "Masuk"}</h2>
      <input
        placeholder="Nama Pengguna"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        style={{ padding: '0.5rem', width: '200px', marginBottom: '1rem' }}
      />
      <br />
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <button onClick={handleSubmit}>
        {isRegister ? "Daftar" : "Masuk"}
      </button>
      <p>
        {isRegister ? "Sudah punya akun?" : "Belum punya akun?"}
        <button onClick={() => { setIsRegister(!isRegister); setError(""); }}>
          {isRegister ? "Masuk" : "Daftar"}
        </button>
      </p>
    </div>
  );
}
