import { useState } from 'react';
import LoginRegister from './LoginRegister';
import SlotGame from './SlotGame';

export default function App() {
  const [user, setUser] = useState(null);

  return (
    <>
      {!user ? (
        <LoginRegister onLogin={setUser} />
      ) : (
        <SlotGame
          user={user}
          onBack={() => setUser(null)} // logout
        />
      )}
    </>
  );
}
