import { useState, useEffect } from 'react';

const slotSymbols = ['🍒', '🍋', '🔔', '🍀', '💎', '7️⃣'];
const betOptions = [800, 1500, 5000, 10000, 100000];
const multipliers = [1, 2, 5, 8, 10, 20];

export default function SlotGame({ user, onBack }) {
  const [reels, setReels] = useState(['🍒', '🍒', '🍒']);
  const [message, setMessage] = useState('');
  const [bet, setBet] = useState(10000);
  const [credits, setCredits] = useState(user.credits);

  const spin = () => {
    if (credits < bet) {
      setMessage("💸 Saldo tidak cukup");
      return;
    }

    const newReels = [
      slotSymbols[Math.floor(Math.random() * slotSymbols.length)],
      slotSymbols[Math.floor(Math.random() * slotSymbols.length)],
      slotSymbols[Math.floor(Math.random() * slotSymbols.length)]
    ];

    let multiplier = 0;
    if (newReels.every(symbol => symbol === newReels[0])) {
      multiplier = multipliers[Math.floor(Math.random() * multipliers.length)];
    }

    const won = bet * multiplier;
    const finalCredit = credits - bet + won;
    const updated = { ...user, credits: finalCredit };
    localStorage.setItem(`user:${user.username}`, JSON.stringify(updated));
    setCredits(finalCredit);
    setReels(newReels);

    if (multiplier > 0) {
      setMessage(`🎉 Menang! x${multiplier} → +${won.toLocaleString()}`);
    } else {
      setMessage("😢 Coba lagi!");
    }
  };

  return (
    <div style={{ padding: '2rem', textAlign: 'center' }}>
      <h1>🎰 Slot Game</h1>
      <p>Kredit: <strong>{credits.toLocaleString()}</strong></p>
      <div>
        {betOptions.map(b => (
          <button key={b} onClick={() => setBet(b)} style={{ margin: '0.25rem' }}>
            {b.toLocaleString()}
          </button>
        ))}
      </div>
      <div style={{ fontSize: '2rem', margin: '1rem' }}>
        {reels.map((r, i) => <span key={i}>{r}</span>)}
      </div>
      <button onClick={spin}>SPIN ({bet.toLocaleString()})</button>
      <p>{message}</p>
      <button onClick={onBack}>⬅ Kembali</button>
    </div>
  );
}
